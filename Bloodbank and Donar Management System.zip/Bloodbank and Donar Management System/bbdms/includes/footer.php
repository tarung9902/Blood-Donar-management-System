  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">DBMS mini project</br>-YOUNUS KHAN & TARUN G</p>
        </div>
        <!-- /.container -->
    </footer>